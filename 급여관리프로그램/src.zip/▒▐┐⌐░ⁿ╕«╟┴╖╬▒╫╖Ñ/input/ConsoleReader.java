package 급여관리프로그램.input;

public class ConsoleReader {

    public String readLine() {
        return Console.readLine();
    }

    public String read() {
        return Console.read();
    }

    public int nextInt() {
        return Console.nextInt();
    }
}